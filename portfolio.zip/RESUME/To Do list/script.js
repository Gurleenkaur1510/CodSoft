document.addEventListener('DOMContentLoaded', function() {
    const taskInput = document.getElementById('taskInput');
    const addTaskButton = document.getElementById('addTaskButton');
    const taskList = document.getElementById('taskList');
    const clearCompletedButton = document.getElementById('clearCompleted');

    function createTaskItem(taskText) {
        const li = document.createElement('li');
        
        const span = document.createElement('span');
        span.textContent = taskText;
        li.appendChild(span);

        const removeButton = document.createElement('button');
        removeButton.textContent = 'Remove';
        removeButton.className = 'remove-btn';
        removeButton.onclick = function() {
            li.remove();
        };
        li.appendChild(removeButton);

        li.onclick = function() {
            li.classList.toggle('completed');
        };

        return li;
    }

    addTaskButton.addEventListener('click', function() {
        const taskText = taskInput.value.trim();
        if (taskText) {
            const newTaskItem = createTaskItem(taskText);
            taskList.appendChild(newTaskItem);
            taskInput.value = ''; // Clear input field
            taskInput.focus(); // Keep focus on input field
        }
    });

    taskInput.addEventListener('keypress', function(event) {
        if (event.key === 'Enter') {
            addTaskButton.click();
        }
    });

    clearCompletedButton.addEventListener('click', function() {
        const completedTasks = document.querySelectorAll('#taskList .completed');
        completedTasks.forEach(task => task.remove());
    });
});

